import React, { useState, useEffect } from "react";
import {
  Search,
  ChevronLeft,
  ChevronRight,
  Filter,
  Star,
  MapPin,
  Calendar,
  Calculator,
  GitCompare,
  Phone,
  Mail,
  Facebook,
  Twitter,
  Instagram,
  Menu,
  X,
} from "lucide-react";

export default function HomePage() {
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [featuredVehicles, setFeaturedVehicles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const categories = ["All", "Bikes", "Scooters", "Electric"];

  // Fetch featured vehicles from API
  useEffect(() => {
    const fetchFeaturedVehicles = async () => {
      try {
        setLoading(true);
        setError(null);

        const params = new URLSearchParams({
          featured: "true",
          limit: "8",
        });

        const response = await fetch(`/api/vehicles?${params}`);

        if (!response.ok) {
          throw new Error(
            `Failed to fetch vehicles: ${response.status} ${response.statusText}`,
          );
        }

        const data = await response.json();

        // Transform data to match our frontend format
        const transformedVehicles = data.vehicles.map((vehicle) => ({
          id: vehicle.id,
          name: vehicle.name,
          brand: vehicle.brand,
          price: vehicle.price_range,
          image:
            vehicle.image_url ||
            "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=400&h=300&fit=crop",
          category: vehicle.category,
          fuelType: vehicle.fuel_type,
          rating: vehicle.rating,
          location: "Multiple Cities", // We'll add location data later
        }));

        setFeaturedVehicles(transformedVehicles);
      } catch (error) {
        console.error("Error fetching vehicles:", error);
        setError(error.message);

        // Fallback to empty array on error
        setFeaturedVehicles([]);
      } finally {
        setLoading(false);
      }
    };

    fetchFeaturedVehicles();
  }, []);

  // Filter vehicles based on category and search
  const filteredVehicles = featuredVehicles.filter((vehicle) => {
    const categoryMatch =
      selectedCategory === "All" || vehicle.category === selectedCategory;
    const searchMatch =
      vehicle.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      vehicle.brand.toLowerCase().includes(searchQuery.toLowerCase());
    return categoryMatch && searchMatch;
  });

  return (
    <div className="min-h-screen bg-[#FBFBFB] dark:bg-gray-900 font-inter">
      {/* Google Fonts */}
      <link
        href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Playfair+Display:wght@400;500;600;700&display=swap"
        rel="stylesheet"
      />

      {/* Mobile Header */}
      <div className="md:hidden w-full bg-white dark:bg-gray-800 flex items-center justify-between px-4 py-3 border-b border-[#E8E8E8] dark:border-gray-700 relative z-50">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-[#8B5CF6] rounded flex items-center justify-center">
            <span className="text-white font-bold text-sm">VB</span>
          </div>
          <span className="font-inter font-semibold text-lg text-black dark:text-white">
            Vahan Bazar
          </span>
        </div>
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="p-2"
        >
          {mobileMenuOpen ? (
            <X className="w-6 h-6 text-black dark:text-white" />
          ) : (
            <Menu className="w-6 h-6 text-black dark:text-white" />
          )}
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div className="md:hidden fixed inset-0 bg-white dark:bg-gray-900 z-40 pt-16">
          <div className="px-4 py-6 space-y-6">
            <a
              href="/browse"
              className="block text-lg font-medium text-black dark:text-white hover:text-[#8B5CF6]"
            >
              Browse Bikes
            </a>
            <a
              href="/compare"
              className="block text-lg font-medium text-black dark:text-white hover:text-[#8B5CF6]"
            >
              Compare
            </a>
            <a
              href="/calculators"
              className="block text-lg font-medium text-black dark:text-white hover:text-[#8B5CF6]"
            >
              Calculators
            </a>
            <a
              href="/showrooms"
              className="block text-lg font-medium text-black dark:text-white hover:text-[#8B5CF6]"
            >
              Showrooms
            </a>
            <a
              href="/sell"
              className="block text-lg font-medium text-black dark:text-white hover:text-[#8B5CF6]"
            >
              Sell Your Bike
            </a>
            <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
              <button className="w-full bg-[#8B5CF6] text-white py-3 rounded-lg font-semibold hover:bg-[#7C3AED] transition-colors">
                Login
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="flex min-h-screen">
        {/* Desktop Sidebar */}
        <div className="hidden md:flex w-64 bg-white dark:bg-gray-800 flex-col relative z-10 border-r border-[#E8E8E8] dark:border-gray-700">
          {/* Logo */}
          <div className="p-6 border-b border-[#E8E8E8] dark:border-gray-700">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-[#8B5CF6] rounded flex items-center justify-center">
                <span className="text-white font-bold text-lg">VB</span>
              </div>
              <div>
                <h1 className="font-playfair font-semibold text-xl text-black dark:text-white">
                  Vahan Bazar
                </h1>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  Two Wheeler Marketplace
                </p>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex-1 p-6 space-y-2">
            <a
              href="/browse"
              className="flex items-center space-x-3 px-4 py-3 rounded-lg text-black dark:text-white hover:bg-[#F3F4F6] dark:hover:bg-gray-700 transition-colors"
            >
              <Search className="w-5 h-5" />
              <span>Browse Bikes</span>
            </a>
            <a
              href="/compare"
              className="flex items-center space-x-3 px-4 py-3 rounded-lg text-black dark:text-white hover:bg-[#F3F4F6] dark:hover:bg-gray-700 transition-colors"
            >
              <GitCompare className="w-5 h-5" />
              <span>Compare</span>
            </a>
            <a
              href="/calculators"
              className="flex items-center space-x-3 px-4 py-3 rounded-lg text-black dark:text-white hover:bg-[#F3F4F6] dark:hover:bg-gray-700 transition-colors"
            >
              <Calculator className="w-5 h-5" />
              <span>Calculators</span>
            </a>
            <a
              href="/showrooms"
              className="flex items-center space-x-3 px-4 py-3 rounded-lg text-black dark:text-white hover:bg-[#F3F4F6] dark:hover:bg-gray-700 transition-colors"
            >
              <MapPin className="w-5 h-5" />
              <span>Showrooms</span>
            </a>
            <a
              href="/upcoming"
              className="flex items-center space-x-3 px-4 py-3 rounded-lg text-black dark:text-white hover:bg-[#F3F4F6] dark:hover:bg-gray-700 transition-colors"
            >
              <Calendar className="w-5 h-5" />
              <span>Upcoming Launches</span>
            </a>
            <a
              href="/sell"
              className="flex items-center space-x-3 px-4 py-3 rounded-lg text-white bg-[#8B5CF6] hover:bg-[#7C3AED] transition-colors"
            >
              <span>Sell Your Bike</span>
            </a>
          </nav>

          {/* Contact Info */}
          <div className="p-6 border-t border-[#E8E8E8] dark:border-gray-700">
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Phone className="w-4 h-4 text-gray-500" />
                <span className="text-sm text-gray-600 dark:text-gray-400">
                  +91 12345 67890
                </span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="w-4 h-4 text-gray-500" />
                <span className="text-sm text-gray-600 dark:text-gray-400">
                  support@vahanbazar.com
                </span>
              </div>
              <div className="flex items-center space-x-4 pt-2">
                <Facebook className="w-4 h-4 text-gray-500 hover:text-[#8B5CF6] cursor-pointer transition-colors" />
                <Twitter className="w-4 h-4 text-gray-500 hover:text-[#8B5CF6] cursor-pointer transition-colors" />
                <Instagram className="w-4 h-4 text-gray-500 hover:text-[#8B5CF6] cursor-pointer transition-colors" />
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col">
          {/* Hero Section */}
          <div className="bg-gradient-to-r from-[#8B5CF6] to-[#EC4899] text-white px-6 py-12 md:px-12 md:py-20">
            <div className="max-w-4xl">
              <h1 className="font-playfair font-bold text-3xl md:text-5xl lg:text-6xl leading-tight mb-6">
                Buy and Sell Bikes
                <span className="block text-[#FDE68A]">in Seconds</span>
              </h1>
              <p className="text-lg md:text-xl text-white/90 mb-8 max-w-2xl leading-relaxed">
                The ultimate bike marketplace for buyers and sellers. Browse
                thousands of bikes, scooters, and EVs with detailed specs,
                compare models, and find your perfect ride.
              </p>

              {/* Search Bar */}
              <div className="bg-white rounded-lg p-2 flex items-center max-w-2xl">
                <Search className="w-5 h-5 text-gray-400 mx-3" />
                <input
                  type="text"
                  placeholder="Search for bikes, brands, models..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="flex-1 py-3 px-2 text-black outline-none"
                />
                <button className="bg-[#8B5CF6] text-white px-6 py-3 rounded-md font-semibold hover:bg-[#7C3AED] transition-colors">
                  Search
                </button>
              </div>
            </div>
          </div>

          {/* Category Filters */}
          <div className="bg-white dark:bg-gray-800 px-6 py-6 border-b border-[#E8E8E8] dark:border-gray-700">
            <div className="flex flex-wrap items-center gap-4">
              <span className="font-semibold text-black dark:text-white">
                Categories:
              </span>
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    selectedCategory === category
                      ? "bg-[#8B5CF6] text-white"
                      : "bg-[#F3F4F6] dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-[#E5E7EB] dark:hover:bg-gray-600"
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>

          {/* Featured Vehicles */}
          <div className="flex-1 px-6 py-8">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="font-playfair font-semibold text-2xl md:text-3xl text-black dark:text-white mb-2">
                  Featured Vehicles
                </h2>
                <p className="text-gray-600 dark:text-gray-400">
                  Discover the best deals on two-wheelers
                </p>
              </div>
              <a
                href="/browse"
                className="flex items-center space-x-2 px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
              >
                <Filter className="w-4 h-4" />
                <span className="text-sm font-medium">View All</span>
              </a>
            </div>

            {error && (
              <div className="mb-8 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
                <p className="text-red-600 dark:text-red-400 text-sm">
                  Error loading vehicles: {error}
                </p>
              </div>
            )}

            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {[1, 2, 3, 4].map((i) => (
                  <div
                    key={i}
                    className="bg-white dark:bg-gray-800 rounded-xl overflow-hidden border border-gray-200 dark:border-gray-700"
                  >
                    <div className="w-full h-48 bg-gray-200 dark:bg-gray-700 animate-pulse"></div>
                    <div className="p-4 space-y-3">
                      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded animate-pulse"></div>
                      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded animate-pulse w-3/4"></div>
                      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded animate-pulse w-1/2"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredVehicles.map((vehicle) => (
                  <a
                    key={vehicle.id}
                    href={`/vehicles/${vehicle.id}`}
                    className="bg-white dark:bg-gray-800 rounded-xl overflow-hidden border border-gray-200 dark:border-gray-700 hover:shadow-lg transition-all duration-300 group cursor-pointer block"
                  >
                    <div className="relative overflow-hidden">
                      <img
                        src={vehicle.image}
                        alt={vehicle.name}
                        className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute top-3 right-3">
                        <span
                          className={`px-2 py-1 rounded-full text-xs font-medium ${
                            vehicle.fuelType === "Electric"
                              ? "bg-green-100 text-green-800"
                              : "bg-blue-100 text-blue-800"
                          }`}
                        >
                          {vehicle.fuelType}
                        </span>
                      </div>
                    </div>
                    <div className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-[#8B5CF6]">
                          {vehicle.brand}
                        </span>
                        <div className="flex items-center space-x-1">
                          <Star className="w-4 h-4 text-yellow-400 fill-current" />
                          <span className="text-sm text-gray-600 dark:text-gray-400">
                            {vehicle.rating}
                          </span>
                        </div>
                      </div>
                      <h3 className="font-semibold text-lg text-black dark:text-white mb-2 group-hover:text-[#8B5CF6] transition-colors">
                        {vehicle.name}
                      </h3>
                      <div className="flex items-center justify-between mb-3">
                        <span className="font-bold text-xl text-black dark:text-white">
                          {vehicle.price}
                        </span>
                        <div className="flex items-center space-x-1 text-gray-500">
                          <MapPin className="w-4 h-4" />
                          <span className="text-sm">{vehicle.location}</span>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <button className="flex-1 bg-[#8B5CF6] text-white py-2 rounded-lg font-semibold hover:bg-[#7C3AED] transition-colors text-sm">
                          View Details
                        </button>
                        <button
                          onClick={(e) => {
                            e.preventDefault();
                            // TODO: Add to comparison
                          }}
                          className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                        >
                          <GitCompare className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </a>
                ))}
              </div>
            )}

            {filteredVehicles.length === 0 && !loading && !error && (
              <div className="text-center py-12">
                <p className="text-gray-500 dark:text-gray-400 text-lg">
                  No vehicles found matching your criteria
                </p>
              </div>
            )}
          </div>

          {/* Quick Actions */}
          <div className="bg-white dark:bg-gray-800 px-6 py-8 border-t border-gray-200 dark:border-gray-700">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <a
                href="/calculators/emi"
                className="flex flex-col items-center p-4 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors group"
              >
                <Calculator className="w-8 h-8 text-[#8B5CF6] mb-2 group-hover:scale-110 transition-transform" />
                <span className="text-sm font-medium text-black dark:text-white">
                  EMI Calculator
                </span>
              </a>
              <a
                href="/calculators/fuel"
                className="flex flex-col items-center p-4 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors group"
              >
                <Calendar className="w-8 h-8 text-[#8B5CF6] mb-2 group-hover:scale-110 transition-transform" />
                <span className="text-sm font-medium text-black dark:text-white">
                  Fuel Cost
                </span>
              </a>
              <a
                href="/showrooms"
                className="flex flex-col items-center p-4 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors group"
              >
                <MapPin className="w-8 h-8 text-[#8B5CF6] mb-2 group-hover:scale-110 transition-transform" />
                <span className="text-sm font-medium text-black dark:text-white">
                  Find Showrooms
                </span>
              </a>
              <a
                href="/test-ride"
                className="flex flex-col items-center p-4 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors group"
              >
                <Phone className="w-8 h-8 text-[#8B5CF6] mb-2 group-hover:scale-110 transition-transform" />
                <span className="text-sm font-medium text-black dark:text-white">
                  Book Test Ride
                </span>
              </a>
            </div>
          </div>
        </div>
      </div>

      <style jsx global>{`
        .font-inter {
          font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
        }
        .font-playfair {
          font-family: 'Playfair Display', Georgia, serif;
        }
      `}</style>
    </div>
  );
}
