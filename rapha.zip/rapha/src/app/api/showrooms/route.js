import sql from "@/app/api/utils/sql";

// GET /api/showrooms - List showrooms with filtering
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const city = searchParams.get('city');
    const brand = searchParams.get('brand');
    const search = searchParams.get('search');
    const limit = parseInt(searchParams.get('limit')) || 50;
    const offset = parseInt(searchParams.get('offset')) || 0;

    let query = `
      SELECT 
        id, name, brand, address, city, state, pincode,
        phone, email, latitude, longitude, services, rating
      FROM showrooms
    `;
    
    const params = [];
    let paramCount = 0;
    const conditions = [];

    if (city) {
      paramCount++;
      conditions.push(`LOWER(city) = LOWER($${paramCount})`);
      params.push(city);
    }

    if (brand) {
      paramCount++;
      conditions.push(`LOWER(brand) = LOWER($${paramCount})`);
      params.push(brand);
    }

    if (search) {
      paramCount++;
      conditions.push(`(
        LOWER(name) LIKE LOWER($${paramCount})
        OR LOWER(brand) LIKE LOWER($${paramCount})
        OR LOWER(city) LIKE LOWER($${paramCount})
        OR LOWER(address) LIKE LOWER($${paramCount})
      )`);
      params.push(`%${search}%`);
    }

    if (conditions.length > 0) {
      query += ` WHERE ${conditions.join(' AND ')}`;
    }

    query += ` ORDER BY rating DESC, name ASC`;
    
    paramCount++;
    query += ` LIMIT $${paramCount}`;
    params.push(limit);
    
    paramCount++;
    query += ` OFFSET $${paramCount}`;
    params.push(offset);

    const showrooms = await sql(query, params);

    // Get total count for pagination
    let countQuery = `SELECT COUNT(*) as total FROM showrooms`;
    const countParams = [];
    let countParamIndex = 0;

    if (conditions.length > 0) {
      countQuery += ` WHERE ${conditions.join(' AND ')}`;
      // Re-add the same parameters for count query
      if (city) {
        countParamIndex++;
        countParams.push(city);
      }
      if (brand) {
        countParamIndex++;
        countParams.push(brand);
      }
      if (search) {
        countParamIndex++;
        countParams.push(`%${search}%`);
      }
    }

    const [countResult] = await sql(countQuery, countParams);
    const total = parseInt(countResult.total);

    return Response.json({
      showrooms,
      pagination: {
        total,
        limit,
        offset,
        hasMore: offset + limit < total
      }
    });

  } catch (error) {
    console.error('Error fetching showrooms:', error);
    return Response.json(
      { error: 'Failed to fetch showrooms' },
      { status: 500 }
    );
  }
}

// POST /api/showrooms - Create a new showroom (for admin use)
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      name, brand, address, city, state, pincode,
      phone, email, latitude, longitude, working_hours, services
    } = body;

    // Validate required fields
    if (!name || !brand || !address || !city || !state || !pincode) {
      return Response.json(
        { error: 'Missing required fields: name, brand, address, city, state, pincode' },
        { status: 400 }
      );
    }

    const result = await sql`
      INSERT INTO showrooms (
        name, brand, address, city, state, pincode,
        phone, email, latitude, longitude, working_hours, services
      ) VALUES (
        ${name}, ${brand}, ${address}, ${city}, ${state}, ${pincode},
        ${phone}, ${email}, ${latitude}, ${longitude}, ${working_hours}, ${services}
      )
      RETURNING *
    `;

    return Response.json(result[0], { status: 201 });

  } catch (error) {
    console.error('Error creating showroom:', error);
    return Response.json(
      { error: 'Failed to create showroom' },
      { status: 500 }
    );
  }
}