import sql from "@/app/api/utils/sql";

// GET /api/vehicles/[id] - Get single vehicle details
export async function GET(request, { params }) {
  try {
    const { id } = params;

    if (!id || isNaN(parseInt(id))) {
      return Response.json({ error: "Invalid vehicle ID" }, { status: 400 });
    }

    const vehicles = await sql`
      SELECT * FROM vehicles 
      WHERE id = ${parseInt(id)} AND status = 'available'
    `;

    if (vehicles.length === 0) {
      return Response.json({ error: "Vehicle not found" }, { status: 404 });
    }

    return Response.json(vehicles[0]);
  } catch (error) {
    console.error("Error fetching vehicle:", error);
    return Response.json({ error: "Failed to fetch vehicle" }, { status: 500 });
  }
}

// PUT /api/vehicles/[id] - Update vehicle details (for admin use)
export async function PUT(request, { params }) {
  try {
    const { id } = params;
    const body = await request.json();

    if (!id || isNaN(parseInt(id))) {
      return Response.json({ error: "Invalid vehicle ID" }, { status: 400 });
    }

    // Check if vehicle exists
    const existingVehicle = await sql`
      SELECT id FROM vehicles WHERE id = ${parseInt(id)}
    `;

    if (existingVehicle.length === 0) {
      return Response.json({ error: "Vehicle not found" }, { status: 404 });
    }

    // Build dynamic update query
    const updates = [];
    const queryParams = [];
    let paramCount = 0;

    const updatableFields = [
      "name",
      "brand",
      "category",
      "price_range",
      "price_numeric",
      "fuel_type",
      "engine_capacity",
      "power",
      "mileage",
      "top_speed",
      "weight",
      "fuel_tank_capacity",
      "transmission",
      "brakes_front",
      "brakes_rear",
      "tire_front",
      "tire_rear",
      "ground_clearance",
      "seat_height",
      "wheelbase",
      "colors",
      "key_features",
      "description",
      "image_url",
      "gallery_urls",
      "is_featured",
      "is_upcoming",
      "launch_date",
      "status",
    ];

    for (const field of updatableFields) {
      if (body[field] !== undefined) {
        paramCount++;
        updates.push(`${field} = $${paramCount}`);
        queryParams.push(body[field]);
      }
    }

    if (updates.length === 0) {
      return Response.json({ error: "No fields to update" }, { status: 400 });
    }

    // Add updated_at timestamp
    paramCount++;
    updates.push(`updated_at = $${paramCount}`);
    queryParams.push(new Date().toISOString());

    // Add ID for WHERE clause
    paramCount++;
    queryParams.push(parseInt(id));

    const query = `
      UPDATE vehicles 
      SET ${updates.join(", ")}
      WHERE id = $${paramCount}
      RETURNING *
    `;

    const result = await sql(query, queryParams);
    return Response.json(result[0]);
  } catch (error) {
    console.error("Error updating vehicle:", error);
    return Response.json(
      { error: "Failed to update vehicle" },
      { status: 500 },
    );
  }
}

// DELETE /api/vehicles/[id] - Delete vehicle (for admin use)
export async function DELETE(request, { params }) {
  try {
    const { id } = params;

    if (!id || isNaN(parseInt(id))) {
      return Response.json({ error: "Invalid vehicle ID" }, { status: 400 });
    }

    // Soft delete by updating status
    const result = await sql`
      UPDATE vehicles 
      SET status = 'deleted', updated_at = CURRENT_TIMESTAMP
      WHERE id = ${parseInt(id)}
      RETURNING id, name
    `;

    if (result.length === 0) {
      return Response.json({ error: "Vehicle not found" }, { status: 404 });
    }

    return Response.json({
      message: "Vehicle deleted successfully",
      vehicle: result[0],
    });
  } catch (error) {
    console.error("Error deleting vehicle:", error);
    return Response.json(
      { error: "Failed to delete vehicle" },
      { status: 500 },
    );
  }
}
