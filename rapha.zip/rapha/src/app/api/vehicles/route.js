import sql from "@/app/api/utils/sql";

// GET /api/vehicles - List vehicles with filtering
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const brand = searchParams.get('brand');
    const fuelType = searchParams.get('fuelType');
    const minPrice = searchParams.get('minPrice');
    const maxPrice = searchParams.get('maxPrice');
    const search = searchParams.get('search');
    const featured = searchParams.get('featured');
    const limit = parseInt(searchParams.get('limit')) || 20;
    const offset = parseInt(searchParams.get('offset')) || 0;

    let query = `
      SELECT 
        id, name, brand, category, price_range, price_numeric, fuel_type,
        engine_capacity, power, mileage, rating, review_count, image_url,
        colors, key_features, description, is_featured
      FROM vehicles 
      WHERE status = 'available'
    `;
    
    const params = [];
    let paramCount = 0;

    if (category && category !== 'All') {
      paramCount++;
      query += ` AND category = $${paramCount}`;
      params.push(category);
    }

    if (brand) {
      paramCount++;
      query += ` AND brand = $${paramCount}`;
      params.push(brand);
    }

    if (fuelType) {
      paramCount++;
      query += ` AND fuel_type = $${paramCount}`;
      params.push(fuelType);
    }

    if (minPrice) {
      paramCount++;
      query += ` AND price_numeric >= $${paramCount}`;
      params.push(parseInt(minPrice));
    }

    if (maxPrice) {
      paramCount++;
      query += ` AND price_numeric <= $${paramCount}`;
      params.push(parseInt(maxPrice));
    }

    if (search) {
      paramCount++;
      query += ` AND (
        LOWER(name) LIKE LOWER($${paramCount})
        OR LOWER(brand) LIKE LOWER($${paramCount})
        OR LOWER(description) LIKE LOWER($${paramCount})
      )`;
      params.push(`%${search}%`);
    }

    if (featured === 'true') {
      query += ` AND is_featured = true`;
    }

    query += ` ORDER BY is_featured DESC, rating DESC, name ASC`;
    
    paramCount++;
    query += ` LIMIT $${paramCount}`;
    params.push(limit);
    
    paramCount++;
    query += ` OFFSET $${paramCount}`;
    params.push(offset);

    const vehicles = await sql(query, params);

    // Get total count for pagination
    let countQuery = `
      SELECT COUNT(*) as total 
      FROM vehicles 
      WHERE status = 'available'
    `;
    
    const countParams = [];
    let countParamIndex = 0;

    if (category && category !== 'All') {
      countParamIndex++;
      countQuery += ` AND category = $${countParamIndex}`;
      countParams.push(category);
    }

    if (brand) {
      countParamIndex++;
      countQuery += ` AND brand = $${countParamIndex}`;
      countParams.push(brand);
    }

    if (fuelType) {
      countParamIndex++;
      countQuery += ` AND fuel_type = $${countParamIndex}`;
      countParams.push(fuelType);
    }

    if (minPrice) {
      countParamIndex++;
      countQuery += ` AND price_numeric >= $${countParamIndex}`;
      countParams.push(parseInt(minPrice));
    }

    if (maxPrice) {
      countParamIndex++;
      countQuery += ` AND price_numeric <= $${countParamIndex}`;
      countParams.push(parseInt(maxPrice));
    }

    if (search) {
      countParamIndex++;
      countQuery += ` AND (
        LOWER(name) LIKE LOWER($${countParamIndex})
        OR LOWER(brand) LIKE LOWER($${countParamIndex})
        OR LOWER(description) LIKE LOWER($${countParamIndex})
      )`;
      countParams.push(`%${search}%`);
    }

    if (featured === 'true') {
      countQuery += ` AND is_featured = true`;
    }

    const [countResult] = await sql(countQuery, countParams);
    const total = parseInt(countResult.total);

    return Response.json({
      vehicles,
      pagination: {
        total,
        limit,
        offset,
        hasMore: offset + limit < total
      }
    });

  } catch (error) {
    console.error('Error fetching vehicles:', error);
    return Response.json(
      { error: 'Failed to fetch vehicles' },
      { status: 500 }
    );
  }
}

// POST /api/vehicles - Create a new vehicle (for admin use)
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      name, brand, category, price_range, price_numeric, fuel_type,
      engine_capacity, power, mileage, top_speed, weight, fuel_tank_capacity,
      transmission, brakes_front, brakes_rear, tire_front, tire_rear,
      ground_clearance, seat_height, wheelbase, colors, key_features,
      description, image_url, gallery_urls, is_featured, is_upcoming, launch_date
    } = body;

    // Validate required fields
    if (!name || !brand || !category || !price_range || !price_numeric || !fuel_type) {
      return Response.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    const result = await sql`
      INSERT INTO vehicles (
        name, brand, category, price_range, price_numeric, fuel_type,
        engine_capacity, power, mileage, top_speed, weight, fuel_tank_capacity,
        transmission, brakes_front, brakes_rear, tire_front, tire_rear,
        ground_clearance, seat_height, wheelbase, colors, key_features,
        description, image_url, gallery_urls, is_featured, is_upcoming, launch_date
      ) VALUES (
        ${name}, ${brand}, ${category}, ${price_range}, ${price_numeric}, ${fuel_type},
        ${engine_capacity}, ${power}, ${mileage}, ${top_speed}, ${weight}, ${fuel_tank_capacity},
        ${transmission}, ${brakes_front}, ${brakes_rear}, ${tire_front}, ${tire_rear},
        ${ground_clearance}, ${seat_height}, ${wheelbase}, ${colors}, ${key_features},
        ${description}, ${image_url}, ${gallery_urls}, ${is_featured || false}, ${is_upcoming || false}, ${launch_date}
      )
      RETURNING *
    `;

    return Response.json(result[0], { status: 201 });

  } catch (error) {
    console.error('Error creating vehicle:', error);
    return Response.json(
      { error: 'Failed to create vehicle' },
      { status: 500 }
    );
  }
}