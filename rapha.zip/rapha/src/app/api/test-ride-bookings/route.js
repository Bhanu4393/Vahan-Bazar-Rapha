import sql from "@/app/api/utils/sql";

// GET /api/test-ride-bookings - List test ride bookings (for admin use)
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const vehicleId = searchParams.get('vehicleId');
    const showroomId = searchParams.get('showroomId');
    const phone = searchParams.get('phone');
    const limit = parseInt(searchParams.get('limit')) || 50;
    const offset = parseInt(searchParams.get('offset')) || 0;

    let query = `
      SELECT 
        trb.*,
        v.name as vehicle_name,
        v.brand as vehicle_brand,
        s.name as showroom_name,
        s.city as showroom_city
      FROM test_ride_bookings trb
      LEFT JOIN vehicles v ON trb.vehicle_id = v.id
      LEFT JOIN showrooms s ON trb.showroom_id = s.id
    `;
    
    const params = [];
    let paramCount = 0;
    const conditions = [];

    if (status) {
      paramCount++;
      conditions.push(`trb.status = $${paramCount}`);
      params.push(status);
    }

    if (vehicleId) {
      paramCount++;
      conditions.push(`trb.vehicle_id = $${paramCount}`);
      params.push(parseInt(vehicleId));
    }

    if (showroomId) {
      paramCount++;
      conditions.push(`trb.showroom_id = $${paramCount}`);
      params.push(parseInt(showroomId));
    }

    if (phone) {
      paramCount++;
      conditions.push(`trb.phone = $${paramCount}`);
      params.push(phone);
    }

    if (conditions.length > 0) {
      query += ` WHERE ${conditions.join(' AND ')}`;
    }

    query += ` ORDER BY trb.created_at DESC`;
    
    paramCount++;
    query += ` LIMIT $${paramCount}`;
    params.push(limit);
    
    paramCount++;
    query += ` OFFSET $${paramCount}`;
    params.push(offset);

    const bookings = await sql(query, params);

    return Response.json({ bookings });

  } catch (error) {
    console.error('Error fetching test ride bookings:', error);
    return Response.json(
      { error: 'Failed to fetch test ride bookings' },
      { status: 500 }
    );
  }
}

// POST /api/test-ride-bookings - Create a new test ride booking
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      customer_name, phone, email, vehicle_id, showroom_id,
      preferred_date, preferred_time, message
    } = body;

    // Validate required fields
    if (!customer_name || !phone || !vehicle_id || !showroom_id || !preferred_date || !preferred_time) {
      return Response.json(
        { error: 'Missing required fields: customer_name, phone, vehicle_id, showroom_id, preferred_date, preferred_time' },
        { status: 400 }
      );
    }

    // Validate phone number format (basic validation)
    const phoneRegex = /^[+]?[\d\s\-()]{10,15}$/;
    if (!phoneRegex.test(phone)) {
      return Response.json(
        { error: 'Invalid phone number format' },
        { status: 400 }
      );
    }

    // Validate email format if provided
    if (email) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        return Response.json(
          { error: 'Invalid email format' },
          { status: 400 }
        );
      }
    }

    // Check if vehicle exists
    const vehicle = await sql`
      SELECT id, name FROM vehicles 
      WHERE id = ${parseInt(vehicle_id)} AND status = 'available'
    `;

    if (vehicle.length === 0) {
      return Response.json(
        { error: 'Vehicle not found or unavailable' },
        { status: 404 }
      );
    }

    // Check if showroom exists
    const showroom = await sql`
      SELECT id, name FROM showrooms 
      WHERE id = ${parseInt(showroom_id)}
    `;

    if (showroom.length === 0) {
      return Response.json(
        { error: 'Showroom not found' },
        { status: 404 }
      );
    }

    // Create the booking
    const result = await sql`
      INSERT INTO test_ride_bookings (
        customer_name, phone, email, vehicle_id, showroom_id,
        preferred_date, preferred_time, message
      ) VALUES (
        ${customer_name}, ${phone}, ${email}, ${parseInt(vehicle_id)}, ${parseInt(showroom_id)},
        ${preferred_date}, ${preferred_time}, ${message}
      )
      RETURNING *
    `;

    // Get the complete booking details with vehicle and showroom info
    const completeBooking = await sql`
      SELECT 
        trb.*,
        v.name as vehicle_name,
        v.brand as vehicle_brand,
        s.name as showroom_name,
        s.city as showroom_city,
        s.phone as showroom_phone
      FROM test_ride_bookings trb
      LEFT JOIN vehicles v ON trb.vehicle_id = v.id
      LEFT JOIN showrooms s ON trb.showroom_id = s.id
      WHERE trb.id = ${result[0].id}
    `;

    return Response.json({
      message: 'Test ride booking created successfully',
      booking: completeBooking[0]
    }, { status: 201 });

  } catch (error) {
    console.error('Error creating test ride booking:', error);
    return Response.json(
      { error: 'Failed to create test ride booking' },
      { status: 500 }
    );
  }
}